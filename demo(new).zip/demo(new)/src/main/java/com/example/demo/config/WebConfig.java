package com.example.demo.config;

import java.nio.file.Paths;

import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import jakarta.persistence.criteria.Path;

public class WebConfig implements WebMvcConfigurer {
	public static final String UPLOAD_DIR = "uploads";

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
	    Path uploadPath = (Path) Paths.get(UPLOAD_DIR).toAbsolutePath().normalize();
	    String resourceLocation = "file:" + uploadPath.toString() + "/";

	    registry.addResourceHandler("/uploads/**")
	            .addResourceLocations(resourceLocation);
	}
}
