package com.example.demo.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "pets")
public class Pet {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(length = 100)
	private String name;

	@Column(length = 50)
	private String species;

	@Column(length = 100)
	private String breed;

	private Integer age;

	@Column(length = 20)
	private String gender;

	@Column(length = 50)
	private String color;

	private Double weight;

	private String photoUrl;

	@ManyToOne
	@JoinColumn(name = "owner_id")
	private User owner;

	@Column(length = 255)
	private String currentOwnerInfo;

	@Lob
	private String treatmentInfo;

	private LocalDateTime createdAt = LocalDateTime.now();

	// getters/setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSpecies() {
		return species;
	}

	public void setSpecies(String species) {
		this.species = species;
	}

	public String getBreed() {
		return breed;
	}

	public void setBreed(String breed) {
		this.breed = breed;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public String getPhotoUrl() {
		return photoUrl;
	}

	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}

	public User getOwner() {
		return owner;
	}

	public void setOwner(User owner) {
		this.owner = owner;
	}

	public String getCurrentOwnerInfo() {
		return currentOwnerInfo;
	}

	public void setCurrentOwnerInfo(String currentOwnerInfo) {
		this.currentOwnerInfo = currentOwnerInfo;
	}

	public String getTreatmentInfo() {
		return treatmentInfo;
	}

	public void setTreatmentInfo(String treatmentInfo) {
		this.treatmentInfo = treatmentInfo;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}
}