package com.example.demo.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.config.WebConfig;
import com.example.demo.model.Pet;
import com.example.demo.model.User;
import com.example.demo.repository.PetRepository;

@Controller
public class PetController {

	
	@Autowired
	private PetRepository petRepository;

	@GetMapping("/pet-profile")
	public String showPetProfile(@SessionAttribute(value = "user", required = false) User sessionUser, Model model) {

		if (sessionUser == null)
			return "redirect:/login";

		model.addAttribute("user", sessionUser);
		model.addAttribute("pet", new Pet());

		List<Pet> pets = petRepository.findByOwnerId(sessionUser.getId());
		model.addAttribute("pets", pets);

		return "pet-profile";
	}

	@PostMapping(path = "/pet-profile", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public String savePet(@SessionAttribute(value = "user", required = false) User sessionUser,
			@ModelAttribute("pet") Pet pet, @RequestParam(name = "photo", required = false) MultipartFile photo,
			Model model) throws IOException {

		if (sessionUser == null)
			return "redirect:/login";

		// เตรียมโฟลเดอร์ uploads ถ้ายังไม่มี
		Path uploadRoot = Paths.get(WebConfig.UPLOAD_DIR).toAbsolutePath().normalize();
		if (!Files.exists(uploadRoot)) {
			Files.createDirectories(uploadRoot);
		}

		// จัดการไฟล์รูป
		if (photo != null && !photo.isEmpty()) {
			String original = photo.getOriginalFilename();
			String ext = "";
			if (original != null && original.lastIndexOf('.') != -1) {
				ext = original.substring(original.lastIndexOf('.'));
			}
			String filename = UUID.randomUUID().toString().replace("-", "") + ext;
			Path target = uploadRoot.resolve(filename);
			Files.copy(photo.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);
			pet.setPhotoUrl("/uploads/" + filename);
		}

		pet.setOwner(sessionUser);
		petRepository.save(pet);

		return "redirect:/pet-profile";
	}
}
