package com.ecom.controller;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Principal;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ecom.model.Pet;
import com.ecom.model.UserDtls;
import com.ecom.service.PetService;
import com.ecom.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/user/pet")
public class PetController {

    @Autowired
    private PetService petService;

    @Autowired
    private UserService userService;

    @ModelAttribute("user")
    public UserDtls getLoggedInUser(Principal principal) {
        if (principal != null) {
            return userService.getUserByEmail(principal.getName());
        }
        return null;
    }

    @GetMapping
    public String showPets(Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }

        String email = principal.getName();
        UserDtls user = userService.getUserByEmail(email);

        List<Pet> pets = petService.getUserPets(user);
        model.addAttribute("pets", pets);

        if (pets == null || pets.isEmpty()) {
            model.addAttribute("noPetsMsg", "คุณยังไม่มีสัตว์เลี้ยงในระบบ");
        }

        return "pet";
    }

    @PostMapping("/add")
    public String addPet(@RequestParam String name,
                         @RequestParam String type,
                         @RequestParam String breed,
                         @RequestParam int age,
                         @RequestParam String color,
                         Principal principal,
                         @RequestParam(required = false) String description,
                         @RequestParam("imagePet") MultipartFile imageFile,
                         HttpSession session) {

        if (principal == null) {
            return "redirect:/login";
        }

        String email = principal.getName();
        UserDtls user = userService.getUserByEmail(email);

        if (user == null) {
            return "redirect:/login";
        }

        String imagePath = "/img/pet_img/default.jpg"; // default image path

        try {
            if (!imageFile.isEmpty()) {
                String originalFilename = imageFile.getOriginalFilename();
                String fileExtension = originalFilename.substring(originalFilename.lastIndexOf(".") + 1).toLowerCase();

                // ตรวจสอบว่าเป็นไฟล์ภาพ
                if (!List.of("jpg", "jpeg", "png", "gif", "webp").contains(fileExtension)) {
                    session.setAttribute("errorMsg", "ไฟล์ต้องเป็นรูปภาพเท่านั้น");
                    return "redirect:/user/pet";
                }

                String fileName = UUID.randomUUID().toString() + "_" + originalFilename.replaceAll("\\s+", "_");
                String uploadDir = "src/main/resources/static/img/pet_img/";
                File uploadFolder = new File(uploadDir);
                if (!uploadFolder.exists()) {
                    uploadFolder.mkdirs();
                }

                Path filePath = Paths.get(uploadDir + fileName);
                Files.copy(imageFile.getInputStream(), filePath);

                imagePath = "/img/pet_img/" + fileName;
            }

            petService.addPet(name, type, breed, age, color, user, description, imagePath);
            session.setAttribute("succMsg", "Pet added successfully!");
        } catch (IOException e) {
            e.printStackTrace();
            session.setAttribute("errorMsg", "Failed to upload image: " + e.getMessage());
        }

        return "redirect:/user/pet";
    }
}