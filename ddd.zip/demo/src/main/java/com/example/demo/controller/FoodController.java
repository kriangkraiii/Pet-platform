package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Food;
import com.example.demo.repository.FoodRepository;

@Controller
@RequestMapping("/admin/foods")
public class FoodController {

    @Autowired
    private FoodRepository foodRepository;

    // แสดงหน้า manage foods
    @GetMapping
    public String listFoods(Model model) {
        model.addAttribute("foods", foodRepository.findAll());
        model.addAttribute("food", new Food()); // สำหรับ form
        return "admin-manage-food";
    }

    // บันทึกอาหารใหม่
    @PostMapping("/save")
    public String saveFood(@ModelAttribute Food food) {
        foodRepository.save(food);
        return "redirect:/admin/foods";
    }

    // แก้ไขอาหาร
    @GetMapping("/edit/{id}")
    public String editFood(@PathVariable Long id, Model model) {
        model.addAttribute("food", foodRepository.findById(id).orElseThrow());
        model.addAttribute("foods", foodRepository.findAll());
        return "admin-manage-food";
    }

    // ลบอาหาร
    @GetMapping("/delete/{id}")
    public String deleteFood(@PathVariable Long id) {
        foodRepository.deleteById(id);
        return "redirect:/admin/foods";
    }
}
