package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@Controller
@SessionAttributes("user") // เก็บ user ไว้ใน session
public class AppController {

    @Autowired
    private UserRepository repo;

    @GetMapping("")
    public String viewHomePage() {
        return "index";
    }

    @GetMapping("/register")
    public String showSignUpForm(Model model) {
        model.addAttribute("user", new User());
        return "signup_form";
    }

    @PostMapping("/process_register")
    public String processRegistration(User user) {
        user.setRole("USER"); // กำหนด role เริ่มต้น
        repo.save(user);
        return "register_success";
    }
    @GetMapping("/login")
    public String showLoginForm(Model model) {
        model.addAttribute("user", new User());
        return "login";
    }

    @PostMapping("/process_login")
    public String processLogin(User user, Model model) {
        User existingUser = repo.findByEmailAndPassword(user.getEmail(), user.getPassword());
        if (existingUser != null) {
            model.addAttribute("user", existingUser); // เก็บ user ใน session

            if ("ADMIN".equalsIgnoreCase(existingUser.getRole())) {
                return "admin-home"; // หน้า Admin
            } else {
                return "home"; // หน้า User
            }
        } else {
            model.addAttribute("error", "Invalid Email or Password");
            return "login";
        }
    }

    @GetMapping("/home")
    public String home() {
        return "home";
    }

    @GetMapping("/pet-profile")
    public String petProfile() {
        return "pet-profile";
    }

    @GetMapping("/food-recommendation")
    public String foodRecommendation() {
        return "food-recommendation";
    }

    @GetMapping("/disease-analyzer")
    public String diseaseAnalyzer() {
        return "disease-analyzer";
    }

    @GetMapping("/forum")
    public String forum() {
        return "forum";
    }

    @GetMapping("/marketplace")
    public String marketplace() {
        return "marketplace";
    }

    @GetMapping("/logout")
    public String logout(SessionStatus status) {
        status.setComplete();
        return "redirect:/login";
    }
}